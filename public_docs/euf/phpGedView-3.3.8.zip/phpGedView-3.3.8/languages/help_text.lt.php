<?php
/*=============================================================
   charset=utf-8
   Project:	phpGedView
   File:	languages/help_text.lt.php
   Author:	John Finlay
   Translation:	Arturas Sleinius
   Comments:	lithuanian Language Help-file for PHPGedView
   Change Log:	2005-07-26 - File created by Arturas Sleinius
   		For other changes read:
   		languages/LANG_CHANGELOG.txt
=============================================================*/
# $Id: help_text.lt.php,v 1.1 2005/08/12 18:49:02 yalnifj Exp $

//-- GENERAL HELP HEADER
$pgv_lang["ah1_help"]				= "_Atnaujinti";

?>