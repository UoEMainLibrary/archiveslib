<?php
/*=================================================
	charset=utf-8
	Project:	phpGedView
	File:		help_text.ar.php
	Author:		John Finlay
	Comments:	Arabic Language Help-file for PhpGedView
        Change Log:	2004-11-29 - File created
   		              For other changes read languages/LANG_CHANGELOG.txt
===================================================*/

if (preg_match("/help_text\...\.php$/", $_SERVER["PHP_SELF"])>0) {
print "You cannot access a language file directly.";
exit;
}

?>