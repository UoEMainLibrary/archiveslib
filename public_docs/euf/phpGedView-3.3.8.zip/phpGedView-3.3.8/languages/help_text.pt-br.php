<?php
/*=================================================
   charset=utf-8
   Project:	phpGedView
   File:	help_text.pt-br.php
   Author:	John Finlay
   Translator:	Maurício Menegazzo Rosa
   Comments:	Brasilian Portugese Language Help-file for PhpGedView
   Change Log:	2004-01-23 - File Created
   2005.02.19 "PhpGedView" and "GEDCOM" made consistent across all language files  G.Kroll (canajun2eh)
===================================================*/
# $Id: help_text.pt-br.php,v 1.3 2005/03/30 23:44:07 yalnifj Exp $

$pgv_lang["mygedview_login_help"]		= "Para obter acesso ao <b>\"Meu Portal\"</b>, você dever ser um usuário registrado no sistema.<br /><br />No \"Meu Portal\" você pode relacionar suas pessoas favoritas, enviar e receber mensagens, ver outros usuários conectados, etc ...<br /><br />Preencha os campos com seu nome de Usuário e Senha para obter acesso e se Conectar ao portal.";
?>