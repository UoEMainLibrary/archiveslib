<?php
//-- this file is for backwards compatibility with older
//-- versions of the GDBI which used to connect through
//-- gdbi.php... this file is depricated and client.php
//-- should be used instead
include "client.php";
?>