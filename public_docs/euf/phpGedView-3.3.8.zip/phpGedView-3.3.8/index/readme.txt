This directory must be writable by PHP.
This is the standard directory for the index files, privacy files and language setting files.