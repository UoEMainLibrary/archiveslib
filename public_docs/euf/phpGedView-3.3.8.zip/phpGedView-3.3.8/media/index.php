<?php
header("Location: ../medialist.php");
exit;
?>
